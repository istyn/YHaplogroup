﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace YHaplogroup
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> haplogroup = new List<string>();
            int[] pChromo;
            string[,] d1 = ReadDNAFile(@"../../DNAS.txt", out pChromo);
            string[,] y = ReadHaplotypeFile(@"../../haplogroups.txt");
            for (int i = pChromo[23]; i < pChromo[24]; i++) //look at Y chromosome
            {
                for (int j = 0; j < y.GetUpperBound(0); j++)    //iterate through the haplogroups
                {
                    if (d1[i, 3] == y[j, 2])    //position matches known haplogroup
                    {
                        if (d1[i, 1] == y[j, 3])  //mutation matches haplogroup
                        {
                            if (!haplogroup.Contains(y[j, 0]))
                            {
                                haplogroup.Add(y[j, 0]);

                            }
                        }
                    }
                }
            }
        }


        public static string[,] ReadHaplotypeFile(string filePath)
        {
            string[,] output = new string[1333, 4];    //preallocated array for Haplogroups
            string theLine = "";
            int x = 0;
            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    string[] fields;
                    while (theLine != null)     //infinite loop with counter x
                    {
                        theLine = sr.ReadLine();
                        if (theLine != null && theLine[0] != '#' && theLine[2] != 'i')
                        {
                            fields = theLine.Split(new char[] { '\t' });
                            output[x, 0] = fields[0];               //group
                            output[x, 1] = fields[1];               //rsid
                            output[x, 2] = fields[2];               //position
                            output[x, 3] = fields[3];               //mutation

                            x++;
                        }
                    }
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("The file could not be read: ");
                Console.WriteLine(e.Message);
            }

            return output;
        }


        public static string[,] ReadDNAFile(string filePath, out int[] chromoPointers)
        {
            chromoPointers = new int[26];                      //pointers to beginning of each chromosome (25+ endPointer)
            int x = 0, i = 0;                             //pointer in string[], and int[] chromoP
            string[,] output = new string[701478, 4];    //preallocated array for ChrisDNA.txt
            string theLine = "";

            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    string[] fields;
                    while (theLine != null)     //infinite loop with counter x
                    {
                        theLine = sr.ReadLine();
                        if (theLine != null && theLine[0] != '#' && theLine[2] != 'i')
                        {
                            fields = theLine.Split(new char[] { '\t' });
                            output[x, 0] = fields[1];                //chromosome Number
                            output[x, 3] = fields[2];               //position
                            output[x, 1] = fields[3];               //Strand 1
                            output[x, 2] = fields[4];               //strand 2
                            /*This if statement saves a pointer to the beginning of every chromosome.
                                Allows comparison of chromosome lengths. */
                            if (x == 0)
                            {
                                chromoPointers[0] = 0;
                            }
                            else if (output[x, 0] != output[x - 1, 0])
                            {
                                chromoPointers[++i] = x;
                            }
                            x++;
                        }
                    }
                    chromoPointers[chromoPointers.GetUpperBound(0)] = x;

                }


            }
            catch (IOException e)
            {
                Console.WriteLine("The file could not be read: ");
                Console.WriteLine(e.Message);
            }

            return output;
        }
    }
}
